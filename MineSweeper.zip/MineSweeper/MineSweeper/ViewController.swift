//
//  ViewController.swift
//  MineSweeper
//
//  Created by Shaima Parveen on 11/26/16.
//  Copyright © 2016 org.cuappdev.lecture4. All rights reserved.
//

import UIKit


class ViewController: UIViewController{

    var mineImageView: UIImageView!
    var mineLocations: [[Int]] = [[Int]]();
    var buttons: [UIButton] = [UIButton]();
    var startButton: UIButton = UIButton(frame: CGRect(x: 150 , y: 25, width:100, height:25));
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addUIElements()
        startButton.backgroundColor = UIColor.blue
        startButton.setTitle("New Game", for: .normal)
        startButton.addTarget(self, action: #selector(addUIElements), for: .touchUpInside)
        view.addSubview(startButton)

        // Do any additional setup after loading the view, typically from a nib.
    }
    func addUIElements(){
        mineLocations = [[Int]]();
        buttons = [UIButton]()
        for r in 0 ..< 16 {
            for c in 0 ..< 16  {
                let button = UIButton(frame: CGRect(x: r*25, y: 50+c*25, width:25, height:25));
                button.backgroundColor = UIColor.gray;
                button.layer.borderWidth = 1;
                button.layer.borderColor = UIColor.white.cgColor;
                button.accessibilityElements = [r,c]
                button.accessibilityValue = "true"
                button.addTarget(self, action: #selector(pressed), for: .touchUpInside)
                view.addSubview(button);
                buttons.append(button);
            }
        }
        let mines: Int =  40;
        var row: Int = 0;
        var column: Int = 0;
        for _ in 0 ..< mines {
            row = Int(arc4random_uniform(16));
            column = Int(arc4random_uniform(16));
            let Location = [row,column]
            if(!mineLocations.contains{$0==Location}){
                mineLocations.append(Location)
            }
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @objc func pressed(sender: UIButton) {
        sender.accessibilityValue = "false"
        var loc: Bool = false;
        var count: Int = 0;
        let xCoord: Int = sender.accessibilityElements?[0] as! Int
        let yCoord: Int = sender.accessibilityElements?[1] as! Int
        for r in 0 ..< mineLocations.count {

            let x: Bool = xCoord == mineLocations[r][0];
            let y: Bool = yCoord == mineLocations[r][1];
            let a: Bool = xCoord + 1 == mineLocations[r][0];
            let b: Bool = xCoord - 1 == mineLocations[r][0];
            let c: Bool = yCoord + 1 == mineLocations[r][1];
            let d: Bool = yCoord - 1 == mineLocations[r][1];

            if(x && y){
                loc = true;
            }
            else{

                //up
                if(x && c){
                count += 1;
                }
                //down
                if(x && d){
                count += 1;
                }
                //right
                if(a && y){
                count += 1;
                }
                //upright
                if(a && c){
                count += 1;

                }
                //downright
                if(a && d){
                count += 1;

                }
                //left
                if(b && y){
                count += 1;

                }//upleft
                if(b && c){
                count += 1;

                }//downleft
                if(b && d){
                count += 1;

            }
            }
        }
        
        if( loc == true){
            sender.layer.borderColor = UIColor.black.cgColor
            for r in 0 ..< mineLocations.count {
                    let mine = UIImage(named: "mine")
                    let redMine = UIImage(named: "redmine")
                    let xCoordinate: Int = mineLocations[r][0];
                    let yCoordinate: Int = mineLocations[r][1];
                    mineImageView = UIImageView(frame: CGRect(x: xCoordinate*25, y: 50 + yCoordinate*25, width: 25, height: 25))
                    if(xCoordinate==xCoord && yCoordinate==yCoord){
                        mineImageView.image = redMine
                    }
                    else{
                        mineImageView.image = mine;
                    }
                    view.addSubview(mineImageView)
            }
            for a in 0..<buttons.count {
                buttons[a].removeTarget(self, action:  #selector(pressed), for: .touchUpInside)
            }
        }
        else if(count>0){
            sender.layer.borderColor = UIColor.black.cgColor
            let buttonTitle = String(count)
            if(sender.title(for: .normal)==nil){
                sender.setTitle(buttonTitle, for: .normal)
            }
        }
        else{
            sender.layer.borderColor = UIColor.black.cgColor
            let bound1: Bool = -1<(yCoord+1)&&(yCoord+1)<16;
            let bound2: Bool = -1<(yCoord-1)&&(yCoord-1)<16;
            let bound3: Bool = -1<(xCoord+1)&&(xCoord+1)<16;
            let bound4: Bool = -1<(xCoord-1)&&(xCoord-1)<16;
            if(bound1){
                let a: Int = (xCoord)*(16) + (yCoord+1);
                if(buttons[a].accessibilityValue == "true"){
                    pressed(sender: buttons[a])
                }
            }
            if(bound1&&bound3){
                let d: Int = (xCoord+1)*(16) + (yCoord+1);
                if(buttons[d].accessibilityValue == "true"){
                    pressed(sender: buttons[d])
                }
            }
            if(bound3){
                let g: Int = (xCoord+1)*(16) + (yCoord);
                if(buttons[g].accessibilityValue == "true"){
                    pressed(sender: buttons[g])
                }
            }
            if(bound4&&bound1){
                let f: Int = (xCoord-1)*(16) + (yCoord+1);
                if(buttons[f].accessibilityValue == "true"){
                    pressed(sender: buttons[f])
                }
            }
            if(bound4){
                let h: Int = (xCoord-1)*(16) + (yCoord);
                if(buttons[h].accessibilityValue == "true"){
                    pressed(sender: buttons[h])
                }
            }
            if(bound2){
                let b: Int = (xCoord)*(16) + (yCoord-1);
                if(buttons[b].accessibilityValue == "true"){
                    pressed(sender: buttons[b])
                }
            }
            if(bound3&&bound2){
                let c: Int = (xCoord+1)*(16) + (yCoord-1);
                if(buttons[c].accessibilityValue == "true"){
                    pressed(sender: buttons[c])
                }
            }
            if(bound4&&bound2){
                let e: Int = (xCoord-1)*(16) + (yCoord-1);
                if(buttons[e].accessibilityValue == "true"){
                    pressed(sender: buttons[e])
                }
            }
            



        }
        
    }
        


}




